package Controllers;

import Models.TaskList;
import Models.Tasks;
import Models.Users;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/multi")
public class Servlet extends HttpServlet {

    public String idUser;
    public String idList;

    public Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String option=request.getParameter("option");

        if (option.equals("premiun")){
            RequestDispatcher ruta =request.getRequestDispatcher("premiun.jsp");
            ruta.forward(request,response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");

        String option=request.getParameter("option");

        Procesos procesos = new Procesos();
        Tasks tasks = new Tasks();

        List<Tasks> tasksTop = new ArrayList<>();
        List<TaskList> taskLists = new ArrayList<>();
        List<Users> user = new ArrayList<>();
        List<TaskList> taskListTop = new ArrayList<>();
        List<Tasks> tasksList = new ArrayList<>();

        switch (option){

            case "verificar":
                String mail=request.getParameter("mail");
                String pass=request.getParameter("pass");

                try {
                    procesos.getUser(mail,pass);
                    idUser=procesos.resultado;

                    user=procesos.showUser(idUser);
                    idList= procesos.getIdList(idUser);
                    tasksTop=procesos.showTasksTop(idList);
                    request.setAttribute("tasksTop",tasksTop);
                    taskListTop=procesos.showListTop(idList);
                    taskLists=procesos.showList(idUser);

                    request.setAttribute("user",user);
                    request.setAttribute("listas",taskLists);
                    request.setAttribute("listaTop",taskListTop);
                    request.setAttribute("user",user);

                    RequestDispatcher ruta =request.getRequestDispatcher("plataforma.jsp");
                    ruta.forward(request,response);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;

            case "prueba":
                try {
                    taskLists=procesos.showList(idUser);
                    user=procesos.showUser(idUser);

                        idList= procesos.getIdList(idUser);
                        tasksTop=procesos.showTasksTop(idList);
                        request.setAttribute("tasksTop",tasksTop);
                        taskListTop=procesos.showListTop(idList);

                        request.setAttribute("user",user);
                        request.setAttribute("listas",taskLists);
                        request.setAttribute("listaTop",taskListTop);

                        RequestDispatcher ruta =request.getRequestDispatcher("prueba.jsp");
                        ruta.forward(request,response);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
            /**---------------------REGISTRAR TARJETA DE CREDITO---------------------**/
            case "registerCard":

                Users users = new Users();
                String idU=request.getParameter("id");
                String cardNumber =request.getParameter("cardNumber");
                String cvv = request.getParameter("cvv");
                String date = request.getParameter("dateCard");

                users.setId(idU);
                users.setIdPlan(request.getParameter("idPlan"));

                try {
                    procesos.registerCreditCard(idU,cardNumber,date,cvv);
                    procesos.updateStateUser(users);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;

            case "showTaskLoad":
                try {
                    tasksTop=procesos.showTasksTop(idList);
                    taskListTop=procesos.showListTop(idList);

                    request.setAttribute("tasksTop",tasksTop);
                    request.setAttribute("listaTop",taskListTop);

                    RequestDispatcher ruta =request.getRequestDispatcher("Modulos/viewTasks.jsp");
                    ruta.forward(request,response);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
            /**---------------------MOSTRAR TAREAS---------------------**/
            case "showTask":
                try {
                    tasksTop=procesos.showTasksTop(request.getParameter("idList"));
                    taskListTop=procesos.showListTop(request.getParameter("idList"));
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                request.setAttribute("tasksTop",tasksTop);
                request.setAttribute("user",user);
                request.setAttribute("listas",taskLists);
                request.setAttribute("listaTop",taskListTop);

                RequestDispatcher ruta =request.getRequestDispatcher("Modulos/viewTasks.jsp");
                ruta.forward(request,response);
                break;
            /**---------------------REGISTRAR USUARIO---------------------**/
            case "registerUser":
                    Users users1 = new Users();
                    users1.setUsername(request.getParameter("textUser"));
                    users1.setCorreo(request.getParameter("textMail"));
                    users1.setContraseña(request.getParameter("textPass"));
                try {
                    procesos.newUser(users1);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                break;
            /**---------------------NUEVA LISTA---------------------**/
            case "newList":
                String nameList= request.getParameter("NuevaLista");
                try {
                    procesos.newTaskList(idUser,nameList);
                    taskLists=procesos.showList(idUser);
                    PrintWriter out = response.getWriter();

                    for (TaskList taskList:taskLists) {
                        out.println("<div style='width:100%' class='listado'>");
                        out.println("<p class='text-light' style='margin-bottom: 0; width: 100%; padding: 4px;' onclick='getList(this)'"+"data-id="+taskList.getId());
                        out.println("data-name="+taskList.getNombreLista());
                        out.println(">");
                        out.println(taskList.getNombreLista());
                        out.println("</p>");
                        out.println("<svg xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\"\n" +
                                "width=\"24\" height=\"24\"\n" +
                                "viewBox=\"0 0 172 172\"\n" +
                                "style='fill:#000000; margin-right:7px;' data-bs-toggle=\"modal\" data-bs-target=\"#modalEditList\" data-id= "+taskList.getId()+" data-name='"+taskList.getNombreLista()+"'><g fill=\"none\" fill-rule=\"nonzero\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"butt\" stroke-linejoin=\"miter\" stroke-miterlimit=\"10\" stroke-dasharray=\"\" stroke-dashoffset=\"0\" font-family=\"none\" font-weight=\"none\" font-size=\"none\" text-anchor=\"none\" style=\"mix-blend-mode: normal\"><path d=\"M0,172v-172h172v172z\" fill=\"none\"></path><g fill=\"#838383\"><path d=\"M131.96744,14.33333c-1.83467,0 -3.66956,0.70211 -5.06706,2.09961l-14.33333,14.33333l-10.13411,10.13411l-80.93294,80.93294v28.66667h28.66667l105.40039,-105.40039c2.80217,-2.80217 2.80217,-7.33911 0,-10.13412l-18.53255,-18.53255c-1.3975,-1.3975 -3.23239,-2.09961 -5.06706,-2.09961zM131.96744,31.63411l8.39844,8.39844l-9.26628,9.26628l-8.39844,-8.39844zM112.56706,51.03451l8.39844,8.39844l-76.73372,76.73372h-8.39844v-8.39844z\"></path></g></g></svg>");
                        out.println("</div>");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;

            case "refreshListTop":
                PrintWriter out1 = response.getWriter();
                try {
                    idList= procesos.getIdList(idUser);
                    taskListTop=procesos.showListTop(idList);

                    for (TaskList taskList:taskListTop) {
                        out1.println("<div>");
                        out1.println("<p class='text-primary' style=\"width: 100%; cursor: pointer; margin-bottom: 0\" data-bs-toggle=\"modal\" data-bs-target=\"#lists\" id=\"first\" data-id='"+taskList.getId()+"' data-name='"+taskList.getNombreLista()+"'>");
                        out1.println(taskList.getNombreLista());
                        out1.println("</p>");
                        out1.println("</div>");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;

            /**---------------------REFRESCAR TODAS LAS LISTAS---------------------**/
            case "refreshAllLists":
                try {
                    taskLists=procesos.showList(idUser);
                    PrintWriter out = response.getWriter();
                    for (TaskList taskList:taskLists) {
                        out.println("<div style='width:100%; heigth:44px;' class='listado'>");
                        out.println("<p class='text-light' style='margin-bottom: 0; width: 100%; padding: 4px; margin-left:15px;' onclick='getDateListsTask(this)'"+"data-id="+taskList.getId());
                        out.println(">");
                        out.println(taskList.getNombreLista());
                        out.println("</p>");
                        out.println("</div>");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
            /**---------------------NUEVA TAREA---------------------**/
            case "newTask":
                List<Tasks> allTasks = new ArrayList<>();
                String idList = request.getParameter("idList");
                String task = request.getParameter("task");
                String nameLista = request.getParameter("nameList");
                String notes = request.getParameter("notes");
                String idListSelected = request.getParameter("listSelected");

                try {
                    procesos.newTasks(idList,task,nameLista,notes);
                    allTasks=procesos.showTasksTop(idListSelected);
                    PrintWriter out = response.getWriter();

                    for (Tasks eachTask:allTasks) {
                        out.println("<div id='"+eachTask.getId()+"' class='listado' style=\"width: 97%; height: 42px; cursor: pointer; margin-top: 10px;\" onclick=\"getTask(this)\" data-note='"+eachTask.getNotes()+"' data-name='"+eachTask.getNombreTarea()+"' data-id='"+eachTask.getId()+"'>");
                        out.println("<p class=\"text-light\" style=\"margin-bottom:0px; margin-left:8px;width:90%;\">");
                        out.println(eachTask.getNombreTarea());
                        out.println("</p>");
                        if (eachTask.getEstado().equals("En curso")){
                            out.println("<input class=\"form-check-input\" type=\"checkbox\" value=\"\" dataid='"+eachTask.getId()+"' id=\"flexCheckDefault\" onclick=\"updateTask(this)\">");
                        }else {
                            out.println("<input class=\"form-check-input\" type=\"checkbox\" value=\"\" dataid='"+eachTask.getId()+"' id=\"flexCheckDefault\" onclick=\"updateTask(this)\" checked>");
                        }
                        out.println("</div>");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
            /**---------------------ACTUALIZAR TAREA---------------------**/
            case "updateTask":
                tasks.setId(request.getParameter("idTask"));
                tasks.setNombreTarea(request.getParameter("valueTask"));
                try {
                    procesos.updateTasks(tasks);
                    tasksList=procesos.showTasksTop(request.getParameter("listSelected"));
                    PrintWriter out = response.getWriter();

                    for (Tasks eachTask:tasksList) {
                        out.println("<div id='"+eachTask.getId()+"' class=\"d-flex align-items-center\" style=\"width: 97%; height: 42px; cursor: pointer; margin-top: 10px;\" onclick=\"getTask(this)\" data-note='"+eachTask.getNotes()+"' data-name='"+eachTask.getNombreTarea()+"' data-id='"+eachTask.getId()+"'>");
                        out.println("<p class=\"text-light\" style=\"margin-bottom:0px; margin-left:8px;width:90%\">");
                        out.println(eachTask.getNombreTarea());
                        out.println("</p>");
                        if (eachTask.getEstado().equals("En curso")){
                            out.println("<input class=\"form-check-input\" type=\"checkbox\" value=\"\" dataid='"+eachTask.getId()+"' id=\"flexCheckDefault\" onclick=\"updateTask(this)\">");
                        }else {
                            out.println("<input class=\"form-check-input\" type=\"checkbox\" value=\"\" dataid='"+eachTask.getId()+"' id=\"flexCheckDefault\" onclick=\"updateTask(this)\" checked>");
                        }
                        out.println("</div>");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
            /**---------------------ACTUALIZAR ESTADO DE TAREA---------------------**/
            case "updateStateTask":
                    tasks.setId(request.getParameter("idTask"));
                    tasks.setEstado(request.getParameter("state"));
                try {
                    procesos.updateStateTask(tasks);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
            /**---------------------ACTUALIZAR NOTA---------------------**/
            case "updateNote":
                tasks.setId(request.getParameter("idTask"));
                tasks.setNotes(request.getParameter("valueNote"));

                try {
                    procesos.updateNotes(tasks);
                    tasksList=procesos.showTasksTop(request.getParameter("listSelected"));
                    PrintWriter out = response.getWriter();

                    for (Tasks eachTask:tasksList){
                        out.println("<div id='"+eachTask.getId()+"' class=\"d-flex align-items-center\" style=\"width: 97%; height: 42px; cursor: pointer; margin-top: 10px;\" onclick=\"getTask(this)\" data-note='"+eachTask.getNotes()+"' data-name='"+eachTask.getNombreTarea()+"' data-id='"+eachTask.getId()+"'>");
                        out.println("<p class=\"text-light\" style=\"margin-bottom:0px; margin-left:8px;width:90%;\">");
                        out.println(eachTask.getNombreTarea());
                        out.println("</p>");
                        if (eachTask.getEstado().equals("En curso")){
                            out.println("<input class=\"form-check-input\" type=\"checkbox\" value=\"\" dataid='"+eachTask.getId()+"' id=\"flexCheckDefault\" onclick=\"updateTask(this)\">");
                        }else {
                            out.println("<input class=\"form-check-input\" type=\"checkbox\" value=\"\" dataid='"+eachTask.getId()+"' id=\"flexCheckDefault\" onclick=\"updateTask(this)\" checked>");
                        }
                        out.println("</div>");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
            /**---------------------ACTUALIZAR LISTA---------------------**/
            case "updateList":
                TaskList taskList = new TaskList();
                taskList.setId(request.getParameter("idList"));
                taskList.setNombreLista(request.getParameter("nameList"));

                try {
                    procesos.updateList(taskList);
                    taskLists=procesos.showList(idUser);

                    PrintWriter out = response.getWriter();
                    for (TaskList lists:taskLists) {
                        out.println("<div style='width:100%' class='listado'>");
                        out.println("<p class='text-light' style='margin-bottom: 0; width: 100%; padding: 4px;' onclick='getList(this)' data-id="+lists.getId()+" data-name='"+lists.getNombreLista()+"'>");
                        out.println(lists.getNombreLista());
                        out.println("</p>");
                        out.println("<svg xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\"\n" +
                                "width=\"24\" height=\"24\"\n" +
                                "viewBox=\"0 0 172 172\"\n" +
                                "style='fill:#000000; margin-right:7px;' data-bs-toggle=\"modal\" data-bs-target=\"#modalEditList\" data-id= "+lists.getId()+" data-name='"+lists.getNombreLista()+"'><g fill=\"none\" fill-rule=\"nonzero\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"butt\" stroke-linejoin=\"miter\" stroke-miterlimit=\"10\" stroke-dasharray=\"\" stroke-dashoffset=\"0\" font-family=\"none\" font-weight=\"none\" font-size=\"none\" text-anchor=\"none\" style=\"mix-blend-mode: normal\"><path d=\"M0,172v-172h172v172z\" fill=\"none\"></path><g fill=\"#838383\"><path d=\"M131.96744,14.33333c-1.83467,0 -3.66956,0.70211 -5.06706,2.09961l-14.33333,14.33333l-10.13411,10.13411l-80.93294,80.93294v28.66667h28.66667l105.40039,-105.40039c2.80217,-2.80217 2.80217,-7.33911 0,-10.13412l-18.53255,-18.53255c-1.3975,-1.3975 -3.23239,-2.09961 -5.06706,-2.09961zM131.96744,31.63411l8.39844,8.39844l-9.26628,9.26628l-8.39844,-8.39844zM112.56706,51.03451l8.39844,8.39844l-76.73372,76.73372h-8.39844v-8.39844z\"></path></g></g></svg>");
                        out.println("</div>");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
            /**---------------------ELIMINAR TAREA---------------------**/
            case "deleteTask":
                tasks.setId(request.getParameter("idTask"));
                try {
                    procesos.deleteTasks(tasks);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
            /**---------------------ELIMINAR LISTA---------------------**/
            case "deleteList":
                TaskList taskList1 = new TaskList();
                taskList1.setId(request.getParameter("idList"));

                try {
                    procesos.deleteList(taskList1);
                    taskLists=procesos.showList(idUser);

                    PrintWriter out = response.getWriter();
                    for (TaskList lists:taskLists) {
                        out.println("<div style='width:100%' class='listado'>");
                        out.println("<p class='text-light' style='margin-bottom: 0; width: 100%; padding: 4px;' onclick='getList(this)' data-id="+lists.getId()+" data-name='"+lists.getNombreLista()+"'>");
                        out.println(lists.getNombreLista());
                        out.println("</p>");
                        out.println("<svg xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\"\n" +
                                "width=\"24\" height=\"24\"\n" +
                                "viewBox=\"0 0 172 172\"\n" +
                                "style='fill:#000000; margin-right:7px;' data-bs-toggle=\"modal\" data-bs-target=\"#modalEditList\" data-id= "+lists.getId()+" data-name='"+lists.getNombreLista()+"'><g fill=\"none\" fill-rule=\"nonzero\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"butt\" stroke-linejoin=\"miter\" stroke-miterlimit=\"10\" stroke-dasharray=\"\" stroke-dashoffset=\"0\" font-family=\"none\" font-weight=\"none\" font-size=\"none\" text-anchor=\"none\" style=\"mix-blend-mode: normal\"><path d=\"M0,172v-172h172v172z\" fill=\"none\"></path><g fill=\"#838383\"><path d=\"M131.96744,14.33333c-1.83467,0 -3.66956,0.70211 -5.06706,2.09961l-14.33333,14.33333l-10.13411,10.13411l-80.93294,80.93294v28.66667h28.66667l105.40039,-105.40039c2.80217,-2.80217 2.80217,-7.33911 0,-10.13412l-18.53255,-18.53255c-1.3975,-1.3975 -3.23239,-2.09961 -5.06706,-2.09961zM131.96744,31.63411l8.39844,8.39844l-9.26628,9.26628l-8.39844,-8.39844zM112.56706,51.03451l8.39844,8.39844l-76.73372,76.73372h-8.39844v-8.39844z\"></path></g></g></svg>");
                        out.println("</div>");
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
                break;
        }
    }
}
