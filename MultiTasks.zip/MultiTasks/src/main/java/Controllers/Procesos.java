package Controllers;

import Models.TaskList;
import Models.Tasks;
import Models.Users;
import conexion.Conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Procesos {

    private static Conexion con = new Conexion();
    private static final Connection cn = con.conexion();
    private CallableStatement objStm;
    public String resultado;
    public String idList;

    /**PROCEDIMIENTOS ALMACENADOS (VISTA)**/

    public void getUser(String correo,String password) throws SQLException {

        objStm= cn.prepareCall("Sp_searchUser ?,?,?");
        objStm.setString(1,correo);
        objStm.setString(2,password);
        objStm.registerOutParameter(3,Types.VARCHAR);
        objStm.execute();

        resultado=objStm.getString(3);
    }

    public String getIdList(String idUser) throws SQLException {

        ResultSet objRs = null;
        objStm= cn.prepareCall("SELECT TOP(1) Id FROM [dbo].[Tbl_TaskList] WHERE IdUser='"+idUser+"'");
        objRs=objStm.executeQuery();

        while (objRs.next()){
            idList=objRs.getString(1);
        }
        return idList;
    }

    public List<Tasks> showTasksTop(String id) throws SQLException {

        ResultSet objRs = null;
        List<Tasks> tasks= new ArrayList<>();
        objStm = cn.prepareCall("SELECT * FROM [dbo].[Tbl_Tasks] WHERE IdTaskList='"+id+"'");
        objRs=objStm.executeQuery();

        while (objRs.next()){

            Tasks list = new Tasks();

            list.setId(objRs.getString(1));
            list.setNombreTarea(objRs.getString(3));
            list.setNotes(objRs.getString(5));
            list.setEstado(objRs.getString(6));
            tasks.add(list);
        }
        return  tasks;
    }

    public  List<Users> showUser(String id) throws SQLException {

        ResultSet objRs = null;
        List<Users> listaUser = new ArrayList<>();

        objStm = cn.prepareCall("Sp_MostrarUsers ?");
        objStm.setString(1,id);
        objStm.execute();
        objRs=objStm.getResultSet();

        while (objRs.next()){
            Users user = new Users();

            user.setId(objRs.getString(1));
            user.setUsername(objRs.getString(2));
            user.setCorreo(objRs.getString(3));
            user.setContraseña(objRs.getString(4));
            user.setEstado(objRs.getString(5));
            listaUser.add(user);
        }
        return listaUser;
    }

    public List<TaskList> showList(String id) throws SQLException {

        ResultSet objRs = null;
        List<TaskList> listaTask= new ArrayList<>();
        objStm = cn.prepareCall("Sp_MostrartaskList ?");
        objStm.setString(1,id);
        objStm.execute();
        objRs=objStm.getResultSet();

        while (objRs.next()){
            TaskList list = new TaskList();

            list.setId(objRs.getString(1));
            list.setIdUser(objRs.getString(2));
            list.setNombreLista(objRs.getString(3));

            listaTask.add(list);
        }
        return  listaTask;
    }

    public List<TaskList> showListTop(String id) throws SQLException {

        ResultSet objRs = null;
        List<TaskList> listaTask= new ArrayList<>();
        objStm = cn.prepareCall("Sp_showListTop ?");
        objStm.setString(1,id);
        objStm.execute();
        objRs=objStm.getResultSet();

        while (objRs.next()){
            TaskList list = new TaskList();

            list.setId(objRs.getString(1));
            list.setIdUser(objRs.getString(2));
            list.setNombreLista(objRs.getString(3));

            listaTask.add(list);
        }
        return  listaTask;
    }

    public List<Tasks> showTasks() throws SQLException {

        ResultSet objRs=null;
        List<Tasks> tasks = new ArrayList<>();
        objStm=cn.prepareCall("Sp_MostrarTask");
        objStm.execute();
        objRs=objStm.getResultSet();

        while (objRs.next()){
            Tasks task = new Tasks();

            task.setId(objRs.getString(1));
            task.setIdTaskList(objRs.getString(2));
            task.setNombreTarea(objRs.getString(3));
            task.setNombreLista(objRs.getString(4));
            task.setEstado(objRs.getString(5));

            tasks.add(task);
        }
        return tasks;
    }



    /**PROCEDIMIENTOS ALMACENADOS (INSERTAR)**/

    public void newUser(Users users) throws SQLException {

        objStm=cn.prepareCall("Sp_InsertarUser ?,?,?");
        objStm.setString(1,users.getUsername());
        objStm.setString(2,users.getCorreo());
        objStm.setString(3,users.getContraseña());
        objStm.execute();
    }

    public void newTaskList(String id,String nameList) throws SQLException {

        objStm=cn.prepareCall("Sp_InsertarTaskList ?,?");
        objStm.setString(1,id);
        objStm.setString(2,nameList);

        objStm.execute();
    }

    public void newTasks(String idList, String task, String list, String notes) throws SQLException {

        objStm=cn.prepareCall("Sp_InsertarTasks ?,?,?,?");
        objStm.setString(1,idList);
        objStm.setString(2,task);
        objStm.setString(3,list);
        objStm.setString(4,notes);

        objStm.execute();
    }

    public void registerCreditCard (String idUser, String numberCard, String dateCard , String cvv) throws SQLException {
        objStm = cn.prepareCall("Sp_InsertarCreditCard ?,?,?,?");
        objStm.setString(1,idUser);
        objStm.setString(2,numberCard);
        objStm.setString(3,dateCard);
        objStm.setString(4,cvv);
        objStm.execute();
    }

    /**PROCEDIMIENTOS ALMACENADOS (ACTUALIZAR)**/

    public void updateUser (Users users) throws SQLException {

        objStm = cn.prepareCall("Sp_UpdateUsers ?,?,?,?,?,?,?");
        objStm.setString(1, users.getId());
        objStm.setString(2, users.getNombre());
        objStm.setString(3, users.getApellido());
        objStm.setString(4, users.getUsername());
        objStm.setString(5, users.getCorreo());
        objStm.setString(6, users.getContraseña());
        objStm.registerOutParameter(7, Types.VARCHAR);
        objStm.execute();

        resultado=objStm.getString(7);
    }

    public void updateStateUser (Users users) throws SQLException {
        objStm= cn.prepareCall("UPDATE [dbo].[Tbl_Users] SET Estado = 'Premium' , IdPlan ='"+users.getIdPlan()+"' WHERE Id ='"+users.getId()+"'");
        objStm.executeQuery();
    }

    public void updateList(TaskList taskList) throws SQLException {

        objStm= cn.prepareCall("Sp_UpdateList ?,?");
        objStm.setString(1, taskList.getId());
        objStm.setString(2, taskList.getNombreLista());
        objStm.execute();
    }

    public void updateTasks (Tasks tasks) throws SQLException {
        objStm=cn.prepareCall("Sp_UpdateTask ?,?");
        objStm.setString(1,tasks.getId());
        objStm.setString(2,tasks.getNombreTarea());
        objStm.execute();
    }

    public void updateStateTask (Tasks tasks) throws SQLException {
        objStm=cn.prepareCall("UPDATE [dbo].[Tbl_Tasks] SET Estado='"+tasks.getEstado()+"' WHERE Id='"+tasks.getId()+"' ");
        objStm.executeQuery();
    }

    public void updateNotes (Tasks tasks) throws SQLException {

        objStm= cn.prepareCall("Sp_UpdateNotes ?,?");
        objStm.setString(1,tasks.getId());
        objStm.setString(2,tasks.getNotes());
        objStm.execute();
    }

    /**PROCEDIMIENTOS ALMACENADOS (ELIMINAR)**/

    public void deleteUser (Users users) throws SQLException {
        objStm= cn.prepareCall("Sp_DeleteUser ?");
        objStm.setString(1,users.getId());
        objStm.execute();
    }

    public void deleteList(TaskList taskList) throws SQLException {
        objStm= cn.prepareCall("Sp_DeleteTaskList ?");
        objStm.setString(1,taskList.getId());
        objStm.execute();
    }

    public void deleteTasks (Tasks tasks) throws SQLException {
        objStm= cn.prepareCall("Sp_DeleteTasks ?");
        objStm.setString(1,tasks.getId());
        objStm.execute();
    }

}
