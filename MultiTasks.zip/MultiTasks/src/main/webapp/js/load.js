window.addEventListener("load",load);
window.addEventListener("load",loadModulos);

function load(){
    let xhttp = new XMLHttpRequest();

    xhttp.open("POST","multi?ajax=verificador&option=prueba",true);
    xhttp.onreadystatechange = function (){
        if (this.readyState === 4 && this.status === 200){
            container.innerHTML=xhttp.responseText;
        }
    }
    xhttp.send();
}

function loadModulos(element){
    let idList = $(element).data('id');
    let nameList = $(element).data('name');

    $.ajax({
        type:"POST",
        data:{idList:idList, option:"showTaskLoad",ajax:"verificador" , nameList:nameList},
        url:"multi",
        success:function (data){
            $("#modulos").html(data);
        }
    })
}