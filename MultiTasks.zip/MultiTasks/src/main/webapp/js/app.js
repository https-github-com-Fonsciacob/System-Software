const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");
const formRegisterUser = document.getElementById("registerUser");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});

formRegisterUser.addEventListener("submit",(event)=>{
  let inputUser =formRegisterUser.childNodes[3].childNodes[2];
  let inputMail =formRegisterUser.childNodes[5].childNodes[2];
  let inputPassword =formRegisterUser.childNodes[7].childNodes[2];

  let textUser = inputUser.nextElementSibling.value;
  let textMail = inputMail.nextElementSibling.value;
  let textPass = inputPassword.nextElementSibling.value;

  let xhttp = new XMLHttpRequest();

  if (textUser == ''|| textMail=='' || textPass == '' ){

  }
  else{
    xhttp.onreadystatechange = function (){
      if (this.readyState == 4 && this.status == 200 ){
        container.classList.remove("sign-up-mode");
      }
    }
    xhttp.open("POST",`multi?option=registerUser&textUser=${textUser}&textMail=${textMail}&textPass=${textPass}`,true);
    xhttp.send();
  }
  event.preventDefault();
})

