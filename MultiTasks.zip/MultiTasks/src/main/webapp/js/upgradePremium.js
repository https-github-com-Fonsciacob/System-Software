const formRegisterCard = document.getElementById("registerCard");
const inputCardNumber = document.getElementById("cardNumber");

formRegisterCard.addEventListener("submit",(event)=>{

    let params = new URLSearchParams(location.search);
    let idUser = params.get('id');

    let cardNumber = document.getElementById("cardNumber").value;
    let cvv = document.getElementById("cvv").value;
    let month = document.getElementById("month").value;
    let years = document.getElementById("years").value;
    let dateCard = `${month}/${years}`;
    let idPlan = document.getElementById("selectPlan").value;

    let xhttp = new XMLHttpRequest();

    if (cardNumber == '' || cvv == '' || month == '' || years == ''){

    }else{
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                window.location = "login.jsp";
            }
        }
       xhttp.open("POST",`multi?option=registerCard&cardNumber=${cardNumber}&cvv=${cvv}&dateCard=${dateCard}&id=${idUser}&idPlan=${idPlan}`,true)
       xhttp.send();
    }
    event.preventDefault();
})

inputCardNumber.addEventListener("keyup",(event)=>{
    inputCardNumber.value = event.target.value
        //Eliminamos espacios en blanco
        .replace(/\s/g, '')
        // Eliminar las letras
        .replace(/\D/g, '')
        //Espacio cada cuatro numeros
        .replace(/([0-9]{4})/g,'$1 ')
        //Elimina el ultimo espaciado
        .trim();
})