var container = document.getElementById("container");
var modalEditList = document.getElementById("modalEditList");
var modal = new  bootstrap.Modal(document.getElementById("modalEditList")) ;

    function refreshAllLists(){
        $.ajax({
            type:"POST",
            data:{option:"refreshAllLists"},
            url:"multi",
            success:function (data){
                $("#allLists").html(data);
            }
        })
    }

    function refreshListTop(){
        $.ajax({
            type:"POST",
            data:{option:"refreshListTop"},
            url:"multi",
            success:function (data){
                $("#firstList").html(data);
            }
        })
    }

    $("#addList").submit(function (event){
    let parametros = $("#NuevaLista").val();
    $.ajax({
        type:"POST",
        data:{NuevaLista:parametros, option:"newList"},
        url:"multi",
        beforeSend: function (){
            $('#newLista').modal('hide');
        },
        success: function(data){
            $("#multiCollapseExample2").html(data);
            $("#allLists").html(data);
            refreshAllLists();
            refreshListTop();
        }
    });
    event.preventDefault();
    });

    function getDateListsTask(element){
        let newName = document.getElementById("first");
        let name=$(element).text();
        let id=$(element).data('id');

        newName.innerHTML=name;
        newName.setAttribute("data-id",id);
        newName.setAttribute("data-name",name);
        $("#lists").modal('hide');
    }

//---------------------------------------AÑADIR NUEVA TAREA----------------------------------------------------------------//
    $("#addTask").submit(function (event){

        let List = document.getElementById("first");
        let idList=List.getAttribute("data-id");

        let idListSelected= document.getElementById("listSelect").getAttribute("data-id");

        let name=$("#first").text();
        let task = $("#inputTask").val();
        let notes = $("#inputNotes").val();

        $.ajax({
            type: "POST",
            data: { idList:idList, task:task, notes:notes, nameList:name, listSelected:idListSelected ,option:"newTask"},
            url:"multi",
            beforeSend:function (){
                $("#lists").modal('hide');
                $("#NuevaTarea").modal('hide');
            },
            success: function (data){
                $("#inputNotes").val("");
                $("#inputTask").val("");
                $("#allTasks").html(data);
            }
        });
        event.preventDefault();
    });

    function getList(element){

        let idList = $(element).data('id');
        let nameList = $(element).data('name');

        $.ajax({
            type:"POST",
            data:{idList:idList, option:"showTask",ajax: "verificador" , nameList:nameList},
            url:"multi",
            success:function (data){
                $("#modulos").html(data);
            }
        })
    }

    var i = 0;

modalEditList.addEventListener("show.bs.modal",function (event){
    let element = event.relatedTarget;
    let name = element.getAttribute("data-name");
    let id = element.getAttribute("data-id");

    document.getElementById("editList").value = name;
    document.getElementById("idList").setAttribute("data-id",id);
})

//-------------------------ELMINAR O ACTUALIZAR LISTA---------------------------------------------//
modalEditList.addEventListener("submit",function (event){
    let list = document.getElementById("idList");
    let nameList = document.getElementById("editList");

    let idList = list.getAttribute("data-id");
    let valList = nameList.value;

    let xhttp = new XMLHttpRequest();

    if (document.activeElement.getAttribute("data-qa") == "updateList"){
        xhttp.onreadystatechange = function (){
            if (this.readyState === 4 && this.status === 200){
                modal.hide();
                document.getElementById("multiCollapseExample2").innerHTML = xhttp.responseText;
                refreshAllLists();
            }
        }
        xhttp.open("POST",`multi?option=updateList&nameList=${valList}&idList=${idList}`,true)
        xhttp.send();
    }
    else{
        xhttp.onreadystatechange = function (){
            if (this.readyState === 4 && this.status === 200){
                modal.hide();
                document.getElementById("multiCollapseExample2").innerHTML = xhttp.responseText;
                refreshAllLists();
            }
        }
        xhttp.open("POST",`multi?option=deleteList&idList=${idList}`,true)
        xhttp.send();
    }
    event.preventDefault();
})