var inputTask = document.getElementById("pre");
var ListSelected = document.getElementById("listSelect");
var allTasks = document.getElementById("allTasks");
var detailNotes = document.getElementById("detailNotes");
var btnDeleteTask = document.getElementById("deleteTask");
var i=0;
var q=0;

//--------------------------ACTUALIZAR TAREA
inputTask.addEventListener("change",function (){
    let valInputTask=inputTask.value;
    let idTask = inputTask.getAttribute("data-id");
    let idListSelected = ListSelected.getAttribute("data-id")

    let xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function(){
        if (this.readyState === 4 && this.status === 200){
            allTasks.innerHTML=xhttp.responseText;
        }
    }
    xhttp.open('POST',`multi?option=updateTask&valueTask=${valInputTask}&idTask=${idTask}&listSelected=${idListSelected}`,true)
    xhttp.send();
});

//--------------------------ACTUALIZAR NOTA
detailNotes.addEventListener("change",function (){
    let valNote = detailNotes.value;
    let idTask = inputTask.getAttribute("data-id");
    let idListSelected = ListSelected.getAttribute("data-id");

    let xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function (){
        if (this.readyState === 4 && this.status === 200){
            allTasks.innerHTML=xhttp.responseText;
        }
    }
    xhttp.open("POST",`multi?option=updateNote&valueNote=${valNote}&idTask=${idTask}&listSelected=${idListSelected}`,true)
    xhttp.send();
})

//--------------------------OBTENER DATOS DE LA TAREA
function getTask(element){
    let id = element.getAttribute("data-id")
    inputTask.setAttribute("data-id",id);
    inputTask.value = element.getAttribute("data-name");
    detailNotes.value = element.getAttribute("data-note");
}

//--------------------------ELIMINAR TAREA
btnDeleteTask.addEventListener("click",()=>{
    let idTask=inputTask.getAttribute("data-id");
    let task = document.getElementById(idTask);

    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function (){
        if (this.readyState === 4 && this.status === 200){
            inputTask.value = "";
            task.remove();
        }
    }
    xhttp.open("POST",`multi?option=deleteTask&idTask=${idTask}`,true);
    xhttp.send();
})

//--------------------------ACTUALIZAR ESTADO DE LA TAREA
function updateTask(element){
    let idTask = element.getAttribute("dataid");
    let xhttp = new XMLHttpRequest();

    //Si el checkbox esta marcado actualizará el estado de la tarea como 'Completado' de lo contrario el estado se actualizara 'En Curso'
    if (element.checked){
        xhttp.onreadystatechange = function (){
            if (this.readyState === 4 && this.status === 200){
                element.checked = true;
            }
        }
        xhttp.open("POST",`multi?option=updateStateTask&state=Completado&idTask=${idTask}`,true)
        xhttp.send();
    }else{
        xhttp.onreadystatechange = function (){
            if (this.readyState === 4 && this.status === 200){
                element.checked = false;
            }
        }
        xhttp.open("POST",`multi?option=updateStateTask&state=En curso&idTask=${idTask}`,true)
        xhttp.send();
    }
}

var t;

function intervalo(){
    t = setTimeout(function (){
        document.body.setAttribute("class","bg-unburst");
    },3000)
}

//CAMBIAR DE FONDO
function changeWallpaper(element){
    let state = element.getAttribute("state");
    if (state === "Pendiente"){
        document.getElementById("notificationUpgrade").style.right = "2%";
        document.body.setAttribute("class",element.getAttribute("class"));
        clearTimeout(t);
        intervalo();
    } else{
        document.body.setAttribute("class",element.getAttribute("class"));
    }
}

document.body.addEventListener("click",function (event){
    let close = event.target.getAttribute("data-qa");
    let openSetting = event.target.getAttribute("data-qa");

    //CERRAR VENTANA DE NOTIFICACION DE ACTUALIZAR PREMIUM
    if (close === "closeNotification"){
        document.getElementById("notificationUpgrade").style.right = "-100%";
    }

    //ABRIR PANEL DE BACKGROUNDS
    else if (openSetting == "openSetting"){
        if (q == 0){
            document.getElementById("optionsUser").style.height = "397px";
            q++;
        }else{
            q=0;
            document.getElementById("optionsUser").style.height = "0px";
        }
    }
    //ABRIR LISTA
    else if (event.target.getAttribute("data-qa") === "openAllLists"){
        if (i == 0){
            event.target.style.transform = "rotate(0deg)";
            event.target.style.transition = "0.5s ease";
            i++;
        }else{
            event.target.style.transform = "rotate(180deg)";
            i=0;
        }
    }
})